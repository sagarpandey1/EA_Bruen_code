package edu.mum;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spring.scope.RequestContextFilter;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import edu.mum.rest.service.ProductRestService;

@Configuration
@ApplicationPath("/MongoJerry")
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {
    	
	    register(RequestContextFilter.class);
        register(ProductRestService.class);
    }
}

