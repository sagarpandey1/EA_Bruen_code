package edu.mum.dao;

import java.math.BigInteger;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;

import edu.mum.domain.Product;

public interface ProductDao extends  MongoRepository<Product, String> {
      
	public Product findByName(String name);
}
