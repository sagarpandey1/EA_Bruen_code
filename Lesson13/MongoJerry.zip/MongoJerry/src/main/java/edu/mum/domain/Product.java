package edu.mum.domain;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="product")
 public class Product implements Serializable {
    private static final long serialVersionUID = 5784L;

    @Id
    private String productId;
    private Long id;
	private String name;
    private String description;
    private float price;

     
 	private ProductionStatus status = ProductionStatus.INVALID;

 	public Product()
	{}
	
	
	@PersistenceConstructor
	public Product(String name, String productId,
			String description,float price, Long id, List<Category> categories, Shipping shipping)
	{
			this.id = id;
 			this.name = name;
			this.description = description;
			this.productId = productId;
			 this.price = price;
			 this.categories.addAll(categories);
			 this.shipping = shipping;
	}
 	
    @DBRef(db="category")
     private List<Category> categories = new ArrayList<Category>();
 
    // EXAMPLE: Embedding other "classes" is the Mongo way to go ...
    private Shipping shipping;
    
    
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }
	public List<Category> getCategories() {
		return categories;
	}
	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
 
	public void addCategory(Category category) {
		this.categories.add(category);
//		category.getProducts().add(this);
	}
	public ProductionStatus getStatus() {
		return status;
	}
	public void setStatus(ProductionStatus status) {
		this.status = status;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}


	public Shipping getShipping() {
		return shipping;
	}


	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}
	
 }