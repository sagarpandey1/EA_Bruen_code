package edu.mum;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.dao.CategoryDao;
import edu.mum.dao.ProductDao;
import edu.mum.domain.Category;
import edu.mum.domain.Product;
import edu.mum.domain.Shipping;

@SpringBootApplication
public class MongoJerryApplication implements CommandLineRunner{

	@Autowired
	private ProductDao productDao;
	@Autowired
	private CategoryDao categoryDao;

	public static void main(String[] args) {
		SpringApplication.run(MongoJerryApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {

		loadDataMongoDB();
 
	}	

	private void loadDataMongoDB() {
		
		categoryDao.deleteAll();
		productDao.deleteAll();

		
		Shipping shipping = new Shipping();
		shipping.setWeight(22L);
		shipping.setWidth(33L);
		
		List<Category> categories = new ArrayList();

		Category category = new Category("Sports", "Winter");
		categoryDao.save(category);
		categories.add(category);

		category = new Category("Toys", "Winter");
		categoryDao.save(category);
		categories.add(category);
	
		productDao.save(new Product("Ice Skates","X2345","good", 23.0f, 0L, categories, null ));
		productDao.save(new Product("Sled","S2222","excellent", 102.0f,1L, categories, null ));
		  categories = new ArrayList();
		  // Shipping ignored on  read from client  - NO field in client...
		productDao.save(new Product("Toboggan","T2222","excellent", 102.0f,2L, categories,shipping ));

		// fetch all products
		System.out.println("Products found with findAll():");
		System.out.println("-------------------------------");
		for (Product product : productDao.findAll()) {
			System.out.println("Name " + product.getName());
			System.out.println("Description " + product.getDescription());
			System.out.println("Product ID " + product.getProductId());
			System.out.println("Price " + product.getPrice());
			for (Category categoree : product.getCategories()) {
				System.out.println("Category Name " + categoree.getName());
				System.out.println("Category Description " + categoree.getDescription());
			}
		}
		System.out.println();



	}
	
}
