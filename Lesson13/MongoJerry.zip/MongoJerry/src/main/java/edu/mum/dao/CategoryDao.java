package edu.mum.dao;

import java.math.BigInteger;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;

import edu.mum.domain.Category;

public interface CategoryDao extends  MongoRepository<Category, String>  {
      
	public Category findByName(String name);
}
