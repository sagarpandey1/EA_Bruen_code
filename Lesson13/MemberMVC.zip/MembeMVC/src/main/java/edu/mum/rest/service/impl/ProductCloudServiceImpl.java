package edu.mum.rest.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import edu.mum.domain.Product;
import edu.mum.rest.RemoteApi;
import edu.mum.rest.service.ProductRestService;

@Component("CLOUD")
public class ProductCloudServiceImpl  implements ProductRestService {

	@Autowired
	RemoteApi remoteApi;
	
	public List<Product> findAll() {
		
		RestTemplate restTemplate = remoteApi.getRestTemplate();
  		return Arrays.asList(restTemplate.exchange("http://mongojerry.cfapps.io/MongoJerry/products/", HttpMethod.GET, remoteApi.getHttpEntity(), Product[].class).getBody());

	}

	public Product findOne(Long index) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
 		return (restTemplate.exchange("http://mongojerry.cfapps.io/MongoJerry/products/"+ index, HttpMethod.GET, remoteApi.getHttpEntity(), Product.class).getBody());
	}

	public Product findOne(String string) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
 		return (restTemplate.exchange("http://mongojerry.cfapps.io/MongoJerry/products/"+ string, HttpMethod.GET, remoteApi.getHttpEntity(), Product.class).getBody());
	}

	public Product save(Product product) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
		HttpEntity<Product> httpEntity = new HttpEntity<Product>(product, remoteApi.getHttpHeaders());
 		restTemplate.postForObject("http://mongojerry.cfapps.io/MongoJerry/products/", httpEntity, Product.class);
		return null;
	}

}
