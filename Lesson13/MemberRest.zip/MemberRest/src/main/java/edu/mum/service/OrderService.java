package edu.mum.service;

public interface OrderService {
	
	void processOrder(String  productId, long quantity);
}
