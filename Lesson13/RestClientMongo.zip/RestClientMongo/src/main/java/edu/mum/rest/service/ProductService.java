package edu.mum.rest.service;

import java.util.List;

import edu.mum.domain.Product;


public interface ProductService {


	
	public List<Product> read();

	public Product read(String string);

	public Product write(Product product);

}
