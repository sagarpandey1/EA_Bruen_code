package edu.mum.rest.servce.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import edu.mum.domain.Product;
import edu.mum.domain.Product;
import edu.mum.rest.RemoteApi;
import edu.mum.rest.service.ProductService;

@Component("cloud")
public class ProductServiceCloudImpl implements ProductService {

	@Autowired
	RemoteApi remoteApi;
	
	public List<Product> read() {
		
		RestTemplate restTemplate = remoteApi.getRestTemplate();
 		return Arrays.asList(restTemplate.exchange("http://mongojerry.cfapps.io/MongoJerry/products/", HttpMethod.GET, remoteApi.getHttpEntity(), Product[].class).getBody());
	}

	public Product read(String string) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
 		return (restTemplate.exchange("http://mongojerry.cfapps.io/MongoJerry/products/"+ string, HttpMethod.GET, remoteApi.getHttpEntity(), Product.class).getBody());
	}

	public Product write(Product product) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
		HttpEntity<Product> httpEntity = new HttpEntity<Product>(product, remoteApi.getHttpHeaders());

 		restTemplate.postForObject("http://mongojerry.cfapps.io/MongoJerry/products/", httpEntity, Product.class);
 
 		return null;
	}

}
