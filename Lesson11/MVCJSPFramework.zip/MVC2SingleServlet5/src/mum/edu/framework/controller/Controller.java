package mum.edu.framework.controller;


public interface Controller {}
