Demonstrates form:form, etc.

@ModelAttributes on Method & as Method parameter

Properties file for Field names

Template/Path Variable

ISBN Formattter
Date Formattter   - Uses out-of-box formatter W/Annotation - see Book.java

Custom Version of Date Formatter is also available