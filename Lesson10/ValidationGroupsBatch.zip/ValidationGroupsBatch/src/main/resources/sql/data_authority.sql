 
 INSERT INTO `authority` VALUES (1,'ROLE_ADMIN','Sean','Sean'),
 (2,'ROLE_ADMIN','Bill','Bill'),
 (3,'ROLE_SUPERVISOR','Pete','Pete'),
 (5,'ROLE_SUPERVISOR','Batch','Batch'),
 (4,'ROLE_SUPERVISOR','Paul','Paul');


