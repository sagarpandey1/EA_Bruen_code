 
INSERT INTO `member` VALUES 
(3,22,'Pete','Moss',6,'BMOC',NULL,'Pete'),
(4,44,'Paul','Bearer',7,'KemoSabe',NULL,'Paul'),
(1,35,'Sean','Smith',1,'Kahuna',4,'Sean'),
(2,59,'Bill','IsDueTime',3,'Sri',3,'Bill'),
(5,0,'Batch','OCookies',8,'Big Dog',NULL,'Batch');
 