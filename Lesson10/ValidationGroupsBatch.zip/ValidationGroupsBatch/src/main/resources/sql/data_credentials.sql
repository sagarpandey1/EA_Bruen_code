 
 INSERT INTO `credentials` VALUES ('Bill','','$2a$10$4FNRZfaxqqqMpwgjmSZB4OnvgapxzHrVcOyzVufLE1LVO8W3XD0Ti',NULL),
 ('Paul','','$2a$10$cbn04TjztMMe9iQiIk3tT.sv3HBDg8FGnlO8UIlaKtP5PtiNVqPka',NULL),
 ('Pete','','$2a$10$IDR6r54H9BRu2GcGrViXgeHHtevHadXP/oGyOnNp6GotolE3NQMRa',NULL),
 ('Batch','','$2a$10$IDR6r54H9BRu2GcGrViXgeHHtevHadXP/oGyOnNp6GotolE3NQMRa',NULL),
 ('Sean','','$2a$10$q2mJubO41mryHffrWrEi6e63BDdCgcadq36pXUXnBunZUxDq96Atu',NULL);
 