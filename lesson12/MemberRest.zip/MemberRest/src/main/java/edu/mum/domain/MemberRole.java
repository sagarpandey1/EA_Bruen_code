package edu.mum.domain;

public class MemberRole {

}
