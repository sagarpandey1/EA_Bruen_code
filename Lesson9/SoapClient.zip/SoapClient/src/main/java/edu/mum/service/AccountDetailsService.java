package edu.mum.service;

import edu.mum.wsdl.account.Account;

public interface AccountDetailsService {

	public Account getAccount(Account account);
}
