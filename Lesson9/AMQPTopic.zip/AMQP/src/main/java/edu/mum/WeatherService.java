package edu.mum;

public interface WeatherService {
    String getForecast(String stateCode);
}
