package edu.mum.main;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.context.SecurityContextHolder;

import edu.mum.domain.Address;
import edu.mum.domain.Authority;
import edu.mum.domain.Comment;
import edu.mum.domain.Member;
import edu.mum.domain.Product;
import edu.mum.domain.ProductionStatus;
import edu.mum.domain.UserCredentials;
import edu.mum.security.AuthenticateUser;
import edu.mum.service.AddressService;
import edu.mum.service.CommentService;
import edu.mum.service.CredentialsService;
import edu.mum.service.MemberService;
import edu.mum.service.ProductService;

/*
 * N+1 issue when Many side is declare EAGER
 * One Fetch of LIST of Members
 * N Fetches of each Members List of Addresses
 */
public class Main {
  public static void main(String[] args) throws Throwable {

    ApplicationContext context = new ClassPathXmlApplicationContext("context/applicationContext.xml",
    		"context/batch-config.xml","context/user-job.xml");

    AuthenticationManager authenticationManager = (AuthenticationManager) context.getBean("authenticationManager");

     ProductService productService = (ProductService) context.getBean("productServiceImpl");
     CredentialsService userCredentialsService = (CredentialsService) context.getBean("credentialsServiceImpl");

    
    
    JobLauncher jobLauncher = context.getBean("jobLauncher", JobLauncher.class);
    Job job = context.getBean("SaveProducts", Job.class);
    JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
    jobParametersBuilder.addDate("date", new Date());
    JobParameters jobParameters = jobParametersBuilder.toJobParameters();
    JobExecution jobExecution = jobLauncher.run(job, jobParameters);
    BatchStatus batchStatus = jobExecution.getStatus();

    while (batchStatus.isRunning()) {
        System.out.println("Still running...");
        Thread.sleep(1000);
    }
    System.out.println("Exit status: " + jobExecution.getExitStatus().getExitCode());

    JobInstance jobInstance = jobExecution.getJobInstance();
    System.out.println("job instance Id: " + jobInstance.getId());

	 System.out.println("******* List of Products AND Status");

	 List<Product> products = productService.findAll();
	 for (Product product : products) {
		 System.out.println();
		 System.out.print("Product name: " + product.getName() 
		        + "  Status: " + product.getStatus());
	 }
	 System.out.println();

 
    AuthenticateUser authenticateUser = new AuthenticateUser();

		 while (true)  {
			    try {
			  		authenticateUser.authenticate(authenticationManager);
			  		
			  	} catch (Exception e) {
			  		// TODO Auto-generated catch block
			  		e.printStackTrace();
			  	}
		     try {
		    	    String userName =  SecurityContextHolder.getContext().getAuthentication().getName();
		    	    UserCredentials userCredentials = userCredentialsService.findByUserName(userName);
		    	    Authority authority = userCredentials.getAuthority().get(0);
		    	    Member member = userCredentials.getMember();
		    	    

		    	    if (member.getFirstName().equals("Sean")  || member.getFirstName().equals("Paul"))
		    	    {
		    	    	Product product = 	 productService.findOne(1L);
						if (checkValidStatusForUser(authority,product))
							productService.update(product);
					     
					     product = 	 productService.findOne(3L);
				    	 if (checkValidStatusForUser(authority,product))
				    		 productService.update(product);
		    	    }
		    	    

		    	    if (member.getFirstName().equals("Bill")  || member.getFirstName().equals("Pete"))
		    	    {
				     Product product = 	 productService.findOne(2L);
			    	 if (checkValidStatusForUser(authority,product))
			    		 productService.update(product);

				     product = 	 productService.findOne(4L);
			    	 if (checkValidStatusForUser(authority,product))
			    		 productService.update(product);
		    	    }
}
			  catch ( AccessDeniedException e) {
			 	 System.out.println("****** ACCESS DENIED ! You Need to have Proper ACL to Access!  **********");
			
			  }

			 System.out.println("******* List of Products AND Status");

			 products = productService.findAll();
			 for (Product product : products) {
				 System.out.println();
				 System.out.print("Product name: " + product.getName() 
				        + "  Status: " + product.getStatus());
			 }
			 System.out.println();
		}
		 
   }
  
  private static boolean checkValidStatusForUser(Authority authority, Product product) {
 	 if ( (authority.getAuthority().equals("ROLE_ADMIN") 
			 && product.getStatus().equals(ProductionStatus.BASIC) )
			 ||
			 (authority.getAuthority().equals("ROLE_SUPERVISOR") 
	    			 && product.getStatus().equals(ProductionStatus.DETAILS)) )
		 { return true; } 
 	 		else return false;
  }
 }