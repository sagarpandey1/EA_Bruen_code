package edu.mum.validation.groups;

public interface Production extends Details {

}
