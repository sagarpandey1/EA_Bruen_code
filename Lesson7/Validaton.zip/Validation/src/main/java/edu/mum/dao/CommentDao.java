package edu.mum.dao;

import edu.mum.domain.Comment;

public interface CommentDao extends GenericDao<Comment> {
      
 	}
